import React from "react";
///import "./AdminDashboard.scss"; // Optional if you're using a separate SCSS file

const AdminDashboard: React.FC = () => {
  return (
    <div className="admin-dashboard">
      <h1>customer  Dashboard</h1>
    </div>
  );
};

export default AdminDashboard;
