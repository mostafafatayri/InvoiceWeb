// src/Components/Dashboards/AccountantDashboard.tsx
import React from "react";

const AccountantDashboard: React.FC = () => {
  return <h1>Accountant Dashboard</h1>;
};

export default AccountantDashboard;